// @/components/Map/GoogleMap.tsx

import { MapContainer, TileLayer, Marker, Popup, useMap } from "react-leaflet";
import { Icon } from "leaflet";
import { useEffect, useState } from "react";

interface MapProps {
  mapData: any[]; // Define the type for map data
}

function CustomPopup({
  marker,
  setOpenPopupId,
}: {
  marker: any;
  setOpenPopupId: any;
}) {
  const map = useMap(); // Access the map instance

  const closePopup = () => {
    map.closePopup(); // Close the popup using Leaflet's map method
    setOpenPopupId(null); // Optionally close the popup by resetting state if needed
  };

  return (
    <Popup closeOnClick={false}>
      <div>
        <h6>{marker.name}</h6>
        <button onClick={closePopup} className="leafButtoncloses">
          <span aria-hidden="true">×</span>
        </button>
      </div>
    </Popup>
  );
}

const GoogleleafletMap = ({ mapData }: MapProps) => {
  const [latt, setLatt] = useState(0);
  const [long, setlong] = useState(0);
  const [showPopup, setShowPopup] = useState(false);
  const [activePopup, setActivePopup] = useState<string | null>(null);

  const handleMarkerClick = (markerId: string) => {
    setActivePopup(markerId);
  };

  const handlePoclick = () => {
    setShowPopup(!showPopup);
  };

  const handlePopupClose = () => {
    setActivePopup(null);
  };
  useEffect(() => {
    setLatt(mapData[0]?.coordinates?.lat);
    setlong(mapData[0]?.coordinates?.lng);
  }, [mapData]);

  const customMarkerIcon = new Icon({
    iconUrl: "/assets/images/location-pin.png",
    iconSize: [25, 25], // width and height of the icon
    iconAnchor: [12, 41], // position of the icon relative to its container
    popupAnchor: [1, -34], // position of the popup relative to the icon
  });

  return (
    <>
      {mapData && latt && (
        <MapContainer
          scrollWheelZoom={false}
          center={[
            latt, // Use the first item's lat as fallback
            long, // Use the first item's lng as fallback
          ]}
          zoom={4}
          minZoom={2}
          style={{ height: "640px", width: "100%" }}
        >
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
          />
          {mapData.map((marker: any) => (
            <Marker
              key={marker.id}
              position={[marker.coordinates.lat, marker.coordinates.lng]}
              icon={customMarkerIcon} // Specify the custom icon
            >
              <CustomPopup marker={marker} setOpenPopupId={() => {}} />
            </Marker>
          ))}
        </MapContainer>
      )}
    </>
  );
};

export default GoogleleafletMap;



#-----------------------css 



.leaflet-container a.leaflet-popup-close-button {
  position: absolute;
  top: 0;
  right: 0;
  border: none;
  text-align: center;
  display: none!important;
  width: 24px;
  height: 24px;
  font: 16px/24px Tahoma, Verdana, sans-serif;
  color: #757575;
  text-decoration: none;
  background: transparent;
}


button.leafButtoncloses {
  border: 0px solid transparent;
  background: transparent;
  border-radius: 50%;
  position: absolute;
  top: 4px;
  right: 5px;
  font-size: 17px;
  font-weight: 600;
  cursor: pointer;
}

button.leafButtoncloses:hover{
  color: #ff4d15;
  
}