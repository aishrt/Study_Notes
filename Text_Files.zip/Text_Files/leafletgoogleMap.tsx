// @/components/Map/GoogleMap.tsx

import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
import { Icon } from "leaflet";
import { useEffect, useState } from "react";

interface MapProps {
  mapData: any[]; // Define the type for map data
}

const GoogleleafletMap = ({ mapData }: MapProps) => {
  const [latt, setLatt] = useState(45);
  const [long, setlong] = useState(47);
  const [activePopup, setActivePopup] = useState<string | null>(null);

  const handleMarkerClick = (markerId: string) => {
    setActivePopup(markerId);
  };

  const handlePopupClose = () => {
    setActivePopup(null);
  };
  useEffect(() => {
    setLatt(mapData[0]?.coordinates?.lat);
    setlong(mapData[0]?.coordinates?.lng);
  }, [mapData]);

  const customMarkerIcon = new Icon({
    iconUrl: "/assets/images/location-pin.png",
    iconSize: [25, 25], // width and height of the icon
    iconAnchor: [12, 41], // position of the icon relative to its container
    popupAnchor: [1, -34], // position of the popup relative to the icon
  });

  console.log(mapData, "mapData-------mapData");

  return (
    <>
      {mapData && (
        <MapContainer
          scrollWheelZoom={false}
          center={[
            latt, // Use the first item's lat as fallback
            long, // Use the first item's lng as fallback
          ]}
          zoom={4}
          minZoom={2}
          style={{ height: "640px", width: "100%" }}
        >
          {/* <TileLayer
        attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
      /> */}
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
            url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
          />
          {mapData.map((marker: any) => (
            <>
              {console.log(marker, "marker")}
              <Marker
                key={marker.id}
                position={[marker.coordinates.lat, marker.coordinates.lng]}
                icon={customMarkerIcon} // Specify the custom icon
              >
                {/* <Popup>{marker.name}</Popup> */}
                {activePopup === marker.id && (
                  <Popup
                  // position={[marker.coordinates.lat, marker.coordinates.lng]}
                  // onClose={handlePopupClose}
                  >
                    {marker.name}
                  </Popup>
                )}
              </Marker>
            </>
          ))}
        </MapContainer>
      )}
    </>
  );
};

export default GoogleleafletMap;
// import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
// import { Icon } from "leaflet";
// import { useEffect, useState } from "react";

// interface MapProps {
//   mapData: any[]; // Define the type for map data
// }

// const GoogleleafletMap = ({ mapData }: MapProps) => {
//   const [latt, setLatt] = useState(45);
//   const [long, setlong] = useState(47);
//   const [activePopup, setActivePopup] = useState<string | null>(null);

//   const handleMarkerClick = (markerId: string) => {
//     setActivePopup(markerId);
//   };

//   const handlePopupClose = () => {
//     setActivePopup(null);
//   };

//   useEffect(() => {
//     if (mapData.length > 0) {
//       setLatt(mapData[0]?.coordinates?.lat);
//       setlong(mapData[0]?.coordinates?.lng);
//     }
//   }, [mapData]);

//   const customMarkerIcon = new Icon({
//     iconUrl: "/assets/images/location-pin.png",
//     iconSize: [25, 25], // width and height of the icon
//     iconAnchor: [12, 41], // position of the icon relative to its container
//     popupAnchor: [1, -34], // position of the popup relative to the icon
//   });

//   return (
//     <>
//       {mapData && (
//         <MapContainer
//           scrollWheelZoom={false}
//           center={[
//             latt, // Use the first item's lat as fallback
//             long, // Use the first item's lng as fallback
//           ]}
//           zoom={4}
//           minZoom={2}
//           style={{ height: "640px", width: "100%" }}
//         >
//           <TileLayer
//             attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
//             url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
//           />
//           {mapData.map((marker: any) => (
//             <Marker
//               key={marker.id}
//               position={[marker.coordinates.lat, marker.coordinates.lng]}
//               icon={customMarkerIcon}
//               eventHandlers={{
//                 click: () => handleMarkerClick(marker.id),
//               }}
//             >
//              {activePopup === marker.id && (
//                 <Popup
//                   position={[marker.coordinates.lat, marker.coordinates.lng]}
//                   eventHandlers={{
//                     remove: handlePopupClose,
//                   }}
//                 >
//                   {marker.name}
//                 </Popup>
//               )}
//             </Marker>
//           ))}
//         </MapContainer>
//       )}
//     </>
//   );
// };

// export default GoogleleafletMap;
// import { MapContainer, TileLayer, Marker, Popup } from "react-leaflet";
// import { Icon } from "leaflet";
// import { useEffect, useState } from "react";

// interface MapProps {
//   mapData: any[]; // Define the type for map data
// }

// const GoogleleafletMap = ({ mapData }: MapProps) => {
//   const [latt, setLatt] = useState(45);
//   const [long, setlong] = useState(47);
//   const [activePopup, setActivePopup] = useState<string | null>(null);

//   const handleMarkerClick = (markerId: string) => {
//     setActivePopup(markerId);
//   };

//   const handlePopupClose = () => {
//     setActivePopup(null);
//   };

//   useEffect(() => {
//     if (mapData.length > 0) {
//       setLatt(mapData[0]?.coordinates?.lat);
//       setlong(mapData[0]?.coordinates?.lng);
//     }
//   }, [mapData]);

//   const customMarkerIcon = new Icon({
//     iconUrl: "/assets/images/location-pin.png",
//     iconSize: [25, 25], // width and height of the icon
//     iconAnchor: [12, 41], // position of the icon relative to its container
//     popupAnchor: [1, -34], // position of the popup relative to the icon
//   });

//   return (
//     <>
//       {mapData && (
//         <MapContainer
//           scrollWheelZoom={false}
//           center={[latt, long]} // Use the first item's lat/lng as fallback
//           zoom={4}
//           minZoom={2}
//           style={{ height: "640px", width: "100%" }}
//         >
//           <TileLayer
//             attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
//             url="https://{s}.tile.openstreetmap.fr/hot/{z}/{x}/{y}.png"
//           />
//           {mapData.map((marker: any) => (
//             <Marker
//               key={marker.id}
//               position={[marker.coordinates.lat, marker.coordinates.lng]}
//               icon={customMarkerIcon}
//               eventHandlers={{
//                 click: () => handleMarkerClick(marker.id),
//               }}
//             >
//               {activePopup === marker.id && (
//                 <Popup
//                   position={[marker.coordinates.lat, marker.coordinates.lng]}
//                   // onClose={() => handlePopupClose()}
//                   onClose={true}
//                 >
//                   {marker.name}
//                 </Popup>
//               )}
//             </Marker>
//           ))}
//         </MapContainer>
//       )}
//     </>
//   );
// };

// export default GoogleleafletMap;
